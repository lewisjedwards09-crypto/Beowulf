# Beowulf Website

## GitHub Pages setup

1. Create a new GitHub repository named `beowulf`.
2. Upload `index.html` to the repository.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then click **Save**.
6. GitHub will give you a website URL similar to:
   `https://YOUR-USERNAME.github.io/beowulf/`

Use that URL in Google Sites with **Insert → Embed → By URL**.
